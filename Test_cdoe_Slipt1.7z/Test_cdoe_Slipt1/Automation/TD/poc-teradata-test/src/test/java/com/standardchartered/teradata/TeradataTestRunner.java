package com.standardchartered.teradata;

import com.standardchartered.genie.junit.Genie;
import com.standardchartered.genie.junit.GenieOptions;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Genie.class)
@CucumberOptions(
        junit = {"--step-notifications"},
        features = {"classpath:features"},
        tags = {"not @ignore and not @manual"},
        glue = {"classpath:com/standardchartered/teradata/glue"},
        strict = true)
@GenieOptions(
        displayName = "Teradata Demo",
        labels = {"demo"}
)
public class TeradataTestRunner {
}