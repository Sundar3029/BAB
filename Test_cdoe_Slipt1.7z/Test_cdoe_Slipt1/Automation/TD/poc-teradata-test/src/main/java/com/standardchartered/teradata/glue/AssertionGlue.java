package com.standardchartered.teradata.glue;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.database.SqlQueryHelper;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;

public class AssertionGlue {
    private GenieScenario scenario;

    @Before
    public void before(Scenario scenario) {
        this.scenario = (GenieScenario)scenario;
    }

    @Given("^assert the row count returned is '(\\d+)'$")
    public void assertRowCount(int expectedRowCount) {
        List<Map<String, Object>> results = this.scenario.getAttribute(SqlQueryHelper.QUERY_RESULT);
        assertEquals(expectedRowCount, results.size());
    }
}
