package com.standardchartered.datafabric.glue;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.database.SqlQueryHelper;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;

public class AssertionGlue {
    private GenieScenario scenario;

    @Before
    public void before(Scenario scenario) {
        this.scenario = (GenieScenario)scenario;
    }

    @Given("^assert that the value of both source has the same count$")
    public void assertBothSourceHasSameCount() {
        List<Map<String, Object>> results = this.scenario.getAttribute(SqlQueryHelper.QUERY_RESULT);
        List<Long> counts = results.stream().map(x -> (long)x.get("cnt")).collect(Collectors.toList());
        assertEquals("Unable to find 2 count column", 2, counts.size());
        assertEquals("Number of counts is not as expected", counts.get(0), counts.get(1));
    }
}
