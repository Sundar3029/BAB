package com.standardchartered.datafabric;

import com.standardchartered.genie.junit.Genie;
import com.standardchartered.genie.junit.GenieOptions;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Genie.class)
@CucumberOptions(
        junit = {"--step-notifications"},
        features = {"classpath:features"},
        tags = {"not @ignore and not @manual"},
        glue = {"classpath:com/standardchartered/datafabric/glue"},
        strict = true)
@GenieOptions(
        displayName = "DataFabric Demo",
        labels = {"demo"}
)
public class DataFabricTestRunner {
}