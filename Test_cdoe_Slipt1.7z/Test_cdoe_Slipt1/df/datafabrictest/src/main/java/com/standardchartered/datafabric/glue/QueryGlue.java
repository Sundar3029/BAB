package com.standardchartered.datafabric.glue;

import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.database.SqlQueryHelper;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static org.junit.Assert.fail;

public class QueryGlue {
    private GenieScenario scenario;
    private SqlQueryHelper sqlQueryHelper;
    private static Map<String, String> properties = new HashMap<>();

    @Before
    public void before(Scenario scenario) {
        this.scenario = (GenieScenario) scenario;
        sqlQueryHelper = new SqlQueryHelper(this.scenario);
        loadProperties();
    }

    @Given("^set query token for both environment and source/target date$")
    public void setQueryTokenForEnvironmentAndSourceTargetDate() {
        sqlQueryHelper.addQueryToken("environment", properties.get("environment"));
        sqlQueryHelper.addQueryToken("sourceDate", properties.get("sourceDate"));
        sqlQueryHelper.addQueryToken("targetDate", properties.get("targetDate"));
    }

    private void loadProperties() {
        if (properties.isEmpty()) {
            try (InputStream input = QueryGlue.class.getClassLoader().getResourceAsStream("genie.properties")) {
                Properties prop = new Properties();
                prop.load(input);

                String env = prop.getProperty("df.environment");
                if (env == null || env.isEmpty()) {
                    fail("Unable to locate 'df.environment' in genie.properties");
                }

                properties.put("environment", env);

                String sourceDate = prop.getProperty("df.date.src");
                if (sourceDate == null || sourceDate.isEmpty()) {
                    fail("Unable to locate 'df.date.src' in genie.properties");
                }
                String targetDate = prop.getProperty("df.date.target");
                if (targetDate == null || targetDate.isEmpty()) {
                    fail("Unable to locate 'df.date.target' in genie.properties");
                }

                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat source = new SimpleDateFormat("yyyy_MM_dd");
                SimpleDateFormat target = new SimpleDateFormat("yyyyMMdd");

                properties.put("sourceDate", source.format(formatter.parse(sourceDate)));
                properties.put("targetDate", target.format(formatter.parse(targetDate)));

            } catch (IOException e) {
                fail("Failed to locate genie.properties");
            } catch (ParseException e) {
                fail("'df.date.src' or 'df.date.target' in genie.properties is not of format 'yyyy-MM-dd'");
            }
        }
    }
}
