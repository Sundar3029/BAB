package com.standardchartered.datafabric;

import com.standardchartered.genie.junit.Genie;
import com.standardchartered.genie.junit.GenieOptions;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Genie.class)
@CucumberOptions(
        junit = {"--step-notifications"},
        features = {"classpath:features/PreCheck"},
        tags = {"not @ignore  and not @Option3 and not @manual and not @TableA and not @TableB and not @TableC and not @DATAFABRIC-3109"},
        glue = {"classpath:com/standardchartered/datafabric/glue"},
        strict = true)
@GenieOptions(
        displayName = "DataFabric Demo",
        labels = {"demo"}
)
public class DataFabricTestRunnerPreCheck {
}