package com.standardchartered.datafabric;

import com.standardchartered.genie.junit.Genie;
import com.standardchartered.genie.junit.GenieModuleProperty;
import com.standardchartered.genie.junit.GenieOptions;
import cucumber.api.CucumberOptions;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

/**
 * Created by 1534462 on 7/12/2019.
 */
@RunWith(Enclosed.class)
public class DataFabricTestMultiCountryRunner {
    @RunWith(Genie.class)
    @CucumberOptions(
            junit = {"--step-notifications"},
            features = {"classpath:features"},
            tags = {"not @ignore and not @SIT and not @Option3 and not @manual and not @TableA and not @TableB and not @TableC and not @DATAFABRIC-3109"},
            glue = {"classpath:com/standardchartered/datafabric/glue"},
            strict = true)
    @GenieOptions(
            displayName = "DataFabric Demo",
            labels = {"demo"},
            moduleProperties = {@GenieModuleProperty(key = "df.country", value = "MY"),
                    @GenieModuleProperty(key = "df.system", value = "EBBS")}
    )
    public class DataFabricMYTestRunner {
    }

    @RunWith(Genie.class)
    @CucumberOptions(
            junit = {"--step-notifications"},
            features = {"classpath:features"},
            tags = {"not @ignore and not @SIT and not @Option3 and not @manual and not @TableA and not @TableB and not @TableC and not @DATAFABRIC-3109"},
            glue = {"classpath:com/standardchartered/datafabric/glue"},
            strict = true)
    @GenieOptions(
            displayName = "DataFabric Demo",
            labels = {"demo"},
            moduleProperties = {@GenieModuleProperty(key = "df.country", value = "SG"),
                    @GenieModuleProperty(key = "df.system", value = "EBBS")}
    )
    public class DataFabricSGTestRunner {
    }
}
